/* 原创练习，依据现有教材词汇设计；不是官方考试题。 */
(() => {
  const sets = {
    '08': [
      ['The new clothes shop is ___ the department store.',['opposite','hungry','yesterday'],0,'opposite 表示在对面。'],
      ['I am looking forward to ___ the new shop.',['visit','visiting','visited'],1,'look forward to 后可接动词的 -ing 形式。'],
      ['Where can you buy food?',['At a supermarket.','At a swimming pool.','At a bus stop.'],0,'supermarket 是超市。'],
      ['A ___ is a large building with many shops.',['mall','towel','tent'],0,'mall 是购物中心。'],
      ['Mia wants to buy a shirt. The clothes shop is opposite the supermarket. Where is the shop?',['Opposite the supermarket.','Inside the school.','Next to the park.'],0,'题目说服装店在超市对面。']
    ],
    '09': [
      ['Ben needs a ___ after swimming.',['towel','candle','basket'],0,'towel 是毛巾。'],
      ['This bag costs too much. It is very ___.',['expensive','comfortable','outside'],0,'expensive 是昂贵的。'],
      ['You pay with coins and notes. You pay in ___.',['cash','soap','shampoo'],0,'cash 是现金。'],
      ['A discount makes the price ___.',['lower','higher','later'],0,'折扣通常使价格降低。'],
      ['A towel costs £8, but Ben has £5. Why can he not buy it?',['He does not have enough money.','The shop is closed.','He does not like swimming.'],0,'£5 少于 £8。']
    ],
    '10': [
      ['I want to choose a ___ for Dad’s birthday.',['present','towel','classroom'],0,'present 可以表示礼物。'],
      ['There are six ___ on the birthday cake.',['candles','boots','brooms'],0,'candles 是蜡烛。'],
      ['I see my friend and say ___.',['hello','price','heavy'],0,'hello 用来打招呼。'],
      ['A person visiting your home is a ___.',['guest','wallet','mirror'],0,'guest 是客人。'],
      ['Ella buys her dad a book for his birthday. Who is the book for?',['Her dad.','Her teacher.','Her friend.'],0,'短文说书是送给爸爸的。']
    ],
    '11': [
      ['My bag is big ___ for my books.',['enough','yesterday','opposite'],0,'big enough 意为足够大。'],
      ['The box is very ___. I cannot carry it.',['heavy','pale','thin'],0,'heavy 是沉重的。'],
      ['I put my shopping in a ___.',['basket','teacher','uniform'],0,'basket 是篮子。'],
      ['A ___ colour is light, not dark.',['pale','heavy','expensive'],0,'pale 表示浅色的。'],
      ['Sam wants a big school bag for his books. Which bag does he need?',['One that is large enough.','One that is too small.','One without space for books.'],0,'他需要能装下书的包。']
    ],
    '12': [
      ['We sleep in a ___ when we go camping.',['tent','mirror','wallet'],0,'tent 是帐篷。'],
      ['It is wet outside. Put on your ___.',['boots','candles','baskets'],0,'boots 是靴子。'],
      ['Please ___ some water to the picnic.',['bring','wear','greet'],0,'bring 是带来。'],
      ['A long walk in the countryside is a ___.',['hike','receipt','discount'],0,'hike 是远足。'],
      ['For the trip, we need boots. Tents are already there. What should we bring?',['Boots.','A tent.','A mirror.'],0,'帐篷已经在那里，需要带靴子。']
    ],
    '13': [
      ['Our ___ helps us learn at school.',['teacher','customer','towel'],0,'teacher 是教师。'],
      ['It is warm. May I take my jacket ___?',['off','opposite','after'],0,'take off 可以表示脱下。'],
      ['A ___ is a piece of clothing.',['skirt','blackboard','classroom'],0,'skirt 是半身裙。'],
      ['In winter, I wear a ___ coat.',['thick','thirsty','weekly'],0,'thick 是厚的。'],
      ['The classroom is warm, so Lucy takes off her coat. Why does she take it off?',['She feels warm.','She is going swimming.','Her coat is new.'],0,'教室很暖和。']
    ],
    '14': [
      ['People who work together at a shop are the ___.',['staff','towels','tents'],0,'staff 是工作人员。'],
      ['Some students wear a school ___.',['uniform','receipt','picnic'],0,'uniform 是制服。'],
      ['The person buying something in a shop is a ___.',['customer','shopkeeper','teacher'],0,'customer 是顾客。'],
      ['Yesterday I ___ my friend at the museum.',['saw','see','seeing'],0,'yesterday 对应过去式 saw。'],
      ['Dan saw his mum wearing a uniform at the museum. Where was she?',['At the museum.','At the supermarket.','At the swimming pool.'],0,'句子说明她在博物馆。']
    ],
    '15': [
      ['It is bright and sunny. I wear my ___.',['sunglasses','towel','purse'],0,'sunglasses 是太阳镜。'],
      ['I wear a ___ on my head.',['hat','belt','sock'],0,'hat 戴在头上。'],
      ['A scarf goes around your ___.',['neck','foot','hand'],0,'围巾围在脖子上。'],
      ['Gloves keep your ___ warm.',['hands','feet','ears'],0,'gloves 是手套。'],
      ['It is sunny outside. Ana puts on sunglasses before she goes out. Why?',['The sunlight is bright.','It is raining inside.','She is going to bed.'],0,'阳光很亮，所以她戴上太阳镜。']
    ],
    '16': [
      ['I wear ___ on my feet for running.',['trainers','shirts','pockets'],0,'trainers 可以指运动鞋。'],
      ['A sweater can keep you ___.',['warm','opposite','yesterday'],0,'warm 意为温暖的。'],
      ['These trousers feel nice to wear. They are ___.',['comfortable','expensive','bright'],0,'comfortable 意为舒服的。'],
      ['I put my keys in my ___.',['pocket','teacher','picnic'],0,'pocket 是口袋。'],
      ['Kim wears a T-shirt and comfortable trousers for dancing. What does Kim wear?',['A T-shirt and trousers.','A coat and boots.','A uniform and hat.'],0,'短文写的是 T 恤和舒适的裤子。']
    ]
  };
  for (const [lesson, questions] of Object.entries(sets)) {
    questions.forEach(([stem, options, answer, explanation], i) => {
      // Put correct answers in varied positions while keeping the answer explicit.
      const rotate = i % options.length;
      const choices = options.map((_, j) => options[(j + rotate) % options.length]);
      window.KET_QUESTION_BANK.push({id:`L${lesson}-Q${String(i + 1).padStart(2, '0')}`, day:`L${lesson}`, kind:'choice', stem, options:choices, answer:(answer - rotate + options.length) % options.length, explanation});
    });
  }
})();
